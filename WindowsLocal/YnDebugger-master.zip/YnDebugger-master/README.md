# YnDebugger

# a minimal lightweight windows command line debugger. winx64 compatible.
	The source is compiled and The programm is self explained.

<table>
<tr>
       <th>Author's</th>
       <td><a href="https://sp7.co">Numéro du projet sept sérine</a> (<a href="http://sp7.co">@Sp7</a>)</td>
    </tr>
    <tr>
        <th>Copyright</th>
        <td>2017-2020 The-Sarin-project</td>
    </tr>
    <tr>
        <th>Version</th>
        <td>0.0.1</td>
    </tr>
    <tr>
        <th>Last-Modified</th>
        <td>10.6.17</td>
    </tr>
    <tr>
    	<th>TechInfo</th>
	<td><a href="https://www.virustotal.com/en/file/8dfef4511fe2b8421ade0bd23fc9bad3823bcb3f3d730480a4dc45ee66d6ba82/analysis/1497107365/"> virustotal</a>
	</td>
	</tr>
</table>

# Platforms
       Operating System: Windows10.0* \ Vista \ 8.1 \ & all lower version's.
       Intel® Core™ i5-4460S Processor
       x86 64 bit assembly || x84 32 bit assembly


![](ynd.gif)

	
	
	
	
	
