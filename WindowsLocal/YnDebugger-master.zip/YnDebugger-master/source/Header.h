#pragma once

/*
2017 - 2020
Copyrights: Sp7,
Num?ro du projet sept s?rine
*/

#pragma once
#include "stdafx.h"
#include <windows.h>
#include <stdio.h>
#include <Winternl.h>
#include <cstdio>
#include <tlhelp32.h>
#include <comdef.h>
#include <string>
#include <vector>
#include <sstream>
#include <cstdlib>
#include <iostream>
#include <psapi.h>
#include <tchar.h>
#include <Winternl.h>
#include <string>
#include <tuple>
#include <vector>
#include <memory>
#include <Wtsapi32.h>                                                                                          
#include <stdlib.h>
#include <rpc.h>
#include <cstdio>
#include <stdexcept>
#include <array>
#include <stdlib.h> 
#include <dos.h>
#include <stdio.h>
#include <conio.h>

#ifdef _DEBUG 
#undef free
#define free(p) _free_dbg(p, _NORMAL_BLOCK); *(int*)&p = 0x666;
#endif

#ifndef _DEBUG_ONE
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "Kernel32.lib")
#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib,"Wtsapi32.lib")
#pragma comment(lib,"RpcRT4.lib")
#endif

#define IDR_RUNDLL32_DLL1               101

#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#include <shlwapi.h>
#pragma comment(lib, "shlwapi.lib")
#endif
#endif

#include <stdio.h>
#include <stdint.h>


typedef int(*FUNKY_POINTER)(void);

#include <SDKDDKVer.h>

#define _WIN32_WINNT_WIN10_TH2 _WIN32_WINNT_WIN10
#define _WIN32_WINNT_WIN10_RS1 _WIN32_WINNT_WIN10

#ifdef _UNICODE
typedef wchar_t TCHAR;
#else
typedef char TCHAR;
#endif // _UNICODE
typedef const TCHAR* LPCTSTR;

#ifndef _WIN32_WINNT 
#define _WIN32_WINNT 0x0600     
#endif

using std::string;
using namespace std;

typedef NTSTATUS(WINAPI* _NtQueryInformationProcess)(
	_In_      HANDLE           ProcessHandle,
	_In_      PROCESSINFOCLASS ProcessInformationClass,
	_Out_     PVOID            ProcessInformation,
	_In_      ULONG            ProcessInformationLength,
	_Out_opt_ PULONG           ReturnLength
	);

typedef NTSTATUS(WINAPI* _ZwUnmapViewOfSection)(
	_In_     HANDLE ProcessHandle,
	_In_opt_ PVOID  BaseAddress
	);

typedef struct BASE_RELOCATION_BLOCK {
	DWORD PageAddress;
	DWORD BlockSize;
} BASE_RELOCATION_BLOCK, *PBASE_RELOCATION_BLOCK;

typedef struct BASE_RELOCATION_ENTRY {
	USHORT Offset : 12;
	USHORT Type : 4;
} BASE_RELOCATION_ENTRY, *PBASE_RELOCATION_ENTRY;


struct LOADED_IMAGE64
{
	PIMAGE_NT_HEADERS64 FileHeader;
	ULONG NumberOfSections;
	PIMAGE_SECTION_HEADER Sections;
};

static TCHAR QueryPt = NULL;

std::vector<PCSTR> Srvs = {
	"SearchIndexer.exe",
	"armsvc.exe",
	"TrustedInstaller.exe"
	"COM.EXE"
	"dllhost.exe",
	"McClientAnalytics.exe",
	"ntoskrnl.exe",
	"winlogon.exe",
	"svchost.exe",
	"taskhostw.exe",
	"WmiApSrv",
	"vcpkgsrv.exe",
	"wininit.exe",
	"System Interrupts"
};

#define SE_MIN_WELL_KNOWN_PRIVILEGE (2L)
#define SE_CREATE_TOKEN_PRIVILEGE (2L)
#define SE_ASSIGNPRIMARYTOKEN_PRIVILEGE (3L)
#define SE_LOCK_MEMORY_PRIVILEGE (4L)
#define SE_INCREASE_QUOTA_PRIVILEGE (5L)
#define SE_MACHINE_ACCOUNT_PRIVILEGE (6L)
#define SE_TCB_PRIVILEGE (7L)
#define SE_SECURITY_PRIVILEGE (8L)
#define SE_TAKE_OWNERSHIP_PRIVILEGE (9L)
#define SE_LOAD_DRIVER_PRIVILEGE (10L)
#define SE_SYSTEM_PROFILE_PRIVILEGE (11L)
#define SE_SYSTEMTIME_PRIVILEGE (12L)
#define SE_PROF_SINGLE_PROCESS_PRIVILEGE (13L)
#define SE_INC_BASE_PRIORITY_PRIVILEGE (14L)
#define SE_CREATE_PAGEFILE_PRIVILEGE (15L)
#define SE_CREATE_PERMANENT_PRIVILEGE (16L)
#define SE_BACKUP_PRIVILEGE (17L)
#define SE_RESTORE_PRIVILEGE (18L)
#define SE_SHUTDOWN_PRIVILEGE (19L)
#define SE_DEBUG_PRIVILEGE (20L)
#define SE_AUDIT_PRIVILEGE (21L)
#define SE_SYSTEM_ENVIRONMENT_PRIVILEGE (22L)
#define SE_CHANGE_NOTIFY_PRIVILEGE (23L)
#define SE_REMOTE_SHUTDOWN_PRIVILEGE (24L)
#define SE_UNDOCK_PRIVILEGE (25L)
#define SE_SYNC_AGENT_PRIVILEGE (26L)
#define SE_ENABLE_DELEGATION_PRIVILEGE (27L)
#define SE_MANAGE_VOLUME_PRIVILEGE (28L)
#define SE_IMPERSONATE_PRIVILEGE (29L)
#define SE_CREATE_GLOBAL_PRIVILEGE (30L)
#define SE_TRUSTED_CREDMAN_ACCESS_PRIVILEGE (31L)
#define SE_RELABEL_PRIVILEGE (32L)
#define SE_INC_WORKING_SET_PRIVILEGE (33L)
#define SE_TIME_ZONE_PRIVILEGE (34L)
#define SE_CREATE_SYMBOLIC_LINK_PRIVILEGE (35L)
#define SE_MAX_WELL_KNOWN_PRIVILEGE SE_CREATE_SYMBOLIC_LINK_PRIVILEGE
