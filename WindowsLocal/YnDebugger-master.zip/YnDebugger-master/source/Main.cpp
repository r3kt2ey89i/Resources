
/*
2017 - 2020
Copyrights: Sp7,
Num?ro du projet sept s?rine
*/

#pragma once
#include "stdafx.h"
#include "Header.h"

void PrintHeap(
	PBYTE Data,
	ULONG dwBytes
)
{
	char LRp[4 * 1024];
	bool Flag = false;
	int counter = 0; int y = 0;
	for (ULONG i = 0; i < dwBytes; i += 16) {
		try {
			printf("%.8x: ", i);
		}
		catch (const std::exception& e) {
		}

		for (ULONG j = 0; j < 16; j++) {
			if (i + j < dwBytes) {
				try {
					printf("%.2x ", Data[i + j]);
				}
				catch (const std::exception& e) {

				}
			}
			else {
				printf("?? ");
			}

		}
		for (ULONG j = 0; j < 16; j++) {
			if (i + j < dwBytes && Data[i + j] >= 0x20 && Data[i + j] <= 0x7e) {
				printf("%c", Data[i + j]);
				if (Data[i + j] == 'L') {
					Flag = true;
					counter = 0;
				}
				if (Flag) {
					LRp[y] = Data[i + j];
					y++;
				}
			}
			else {
				printf(".");
			}
		}

		printf("\n");
	}

}

UINT_PTR GetProcessBaseAddress(
		DWORD processID,
		HANDLE processHandle
	)
{
	DWORD_PTR   baseAddress = 0;

	HMODULE     *moduleArray;
	LPBYTE      moduleArrayBytes;
	DWORD       bytesRequired;

	if (processHandle)
	{
		if (EnumProcessModulesEx(processHandle, NULL, 0, &bytesRequired, 0x02))
		{
			if (bytesRequired)
			{
				moduleArrayBytes = (LPBYTE)LocalAlloc(LPTR, bytesRequired);

				if (moduleArrayBytes)
				{
					unsigned int moduleCount;

					moduleCount = bytesRequired / sizeof(HMODULE);
					moduleArray = (HMODULE *)moduleArrayBytes;

					if (EnumProcessModulesEx(processHandle, moduleArray, bytesRequired, &bytesRequired, 0x02))
					{
						baseAddress = (DWORD_PTR)moduleArray[0];
					}

					LocalFree(moduleArrayBytes);
				}
			}
		}

	}

	return baseAddress;
}

std::string Exec(const char* cmd) {
	char buffer[128];
	std::string result = "";
	FILE* pipe = _popen(cmd, "r");
	if (!pipe) throw std::runtime_error("popen() failed!");
	try {
		while (!feof(pipe)) {
			if (fgets(buffer, 128, pipe) != NULL)
				result += buffer;
		}
	}
	catch (...) {
		_pclose(pipe);
		throw;
	}
	_pclose(pipe);
	return result;
}


LPWSTR ConvertToLPWSTR(const std::string& s)
{
	LPWSTR ws = new wchar_t[s.size() + 1];
	copy(s.begin(), s.end(), ws);
	ws[s.size()] = 0;
	return ws;
}

void PatternMatch(
	char Arr[]
)
{
	int x = 0;
	vector<string> Lrp;
	Lrp.resize(20);
	for (int y = 0;y < 19;y++) {
		Lrp[y] = string("");
	}
	char LRPC[19];
	for (int y = 0;y < (12 * 1024);y++) {
		if (Arr[y] == 'L') {
			if (Arr[y + 1] == 'R') {
				if (Arr[y + 2] == 'P') {
					if (Arr[y + 3] == 'C') {
						for (int j = 5; j < 23; j++) {
							LRPC[j - 5] = Arr[y + j];
							Lrp[x].push_back(LRPC[j - 5]);
							//cout << LRPC[j-5];
						}
						x++;
						//Lrpc[0] = LRPC;
					}
				}
			}
		}
	}
#ifdef _UNICODE 
#define DeviceProperties_RunDLL  "DeviceProperties_RunDLLW"
	typedef void(_stdcall *PDEVICEPROPERTIES)(
		HWND hwndStub,
		HINSTANCE hAppInstance,
		LPWSTR lpCmdLine,
		int nCmdShow
		);
#else
#define DeviceProperties_RunDLL  "DeviceProperties_RunDLLA"
	typedef void(_stdcall *PDEVICEPROPERTIES)(
		HWND hwndStub,
		HHINSTANCE hAppInstance,
		LPSTR lpCmdLine,
		int nCmdShow
		);
#endif

	PDEVICEPROPERTIES pDeviceProperties;
}

void InterActive(
)
{
	while (true) {
		cout << endl << endl << endl;
		string Cmd;
		cout << endl << "   Run >>>>";
		getline(cin, Cmd);
		while (Cmd == "" ) {
			if (!(Cmd == "")) { break; }
			getline(cin, Cmd);
			if (cin.fail()) {
				cin.clear();
				cin.ignore();
			}
		}
		cout << endl << endl << endl;
		LPCTSTR Cmnd = ConvertToLPWSTR(Cmd);
		cout << "   [1->show process|0->hide]" << endl;
		cout << "   Options >>";
		int x;
		cin >> x;
		while (x != 1 || x != 0) {
			if (x == 1) { break; }
			if (x == 0) { break; }
			cin >> x;
			if (cin.fail()) {
				cin.clear();
				cin.ignore();
				cout << "wrong input, enter a 0|1";
			}
		}
		for (int r = 0;r < 1000000000;r++) {
		}
		ShellExecute((HWND)GetCurrentProcess(), L"open", Cmnd, NULL, NULL, x);
		PBYTE OutputBuffer = (PBYTE)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, 0);
		PrintHeap(OutputBuffer, 24 * 1024);
	}
		cout << endl << endl << endl;
}

void PrintHex(
	PBYTE Data,
	ULONG dwBytes
)
{
	char LRp[12 * 1024];
	bool Flag = false;
	int counter = 0; int y = 0;
	for (ULONG i = 0; i < dwBytes; i += 16) {
		try {
			printf("%.8x: ", i);
		}
		catch (const std::exception& e) {
			goto EXIT;
		}

		for (ULONG j = 0; j < 16; j++) {
			if (i + j < dwBytes) {
				try {
					printf("%.2x ", Data[i + j]);
				}
				catch (const std::exception& e) {
					goto EXIT;
				}
			}
			else {
				printf("?? ");
			}

		}
		for (ULONG j = 0; j < 16; j++) {
			if (i + j < dwBytes && Data[i + j] >= 0x20 && Data[i + j] <= 0x7e) {
				printf("%c", Data[i + j]);
				if (Data[i + j] == 'L') {
					Flag = true;
					counter = 0;
				}
				if (Flag) {
					LRp[y] = Data[i + j];
					y++;
				}
			}
			else {
				printf(".");
			}
		}

		printf("\n");
	}
EXIT:
	InterActive();
}

typedef struct GrantAccesParam {
	DWORD _myluid = GetCurrentProcessId();
	HANDLE _foreign;
	HANDLE mHandle = GetCurrentProcess();
	DWORD _foreignPuid;
	PCSTR _srvName;
	TCHAR lpdllpath[MAX_PATH];
	LPCTSTR SubKey;
	LPCTSTR Val;
	LPCTSTR lDat;
} AccessParam;

void Align(
	DWORD procID,
	GrantAccesParam &Gp
)
{
	DWORD ReturnLength = 0;
	HMODULE hLocKernel32 = GetModuleHandle(L"Kernel32");
	FARPROC hLocLoadLibrary = GetProcAddress(hLocKernel32, "LoadLibraryA");
	HANDLE hToken;
	TOKEN_PRIVILEGES tkp;
	DWORD address = 0x100579C;
	int value = 0;
	if (OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken))
	{
		LookupPrivilegeValue(NULL, SE_DEBUG_NAME, &tkp.Privileges[0].Luid); 
		tkp.PrivilegeCount = 6;
		tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
		tkp.Privileges[1].Attributes = 0x00040000L;
		tkp.Privileges[2].Attributes = 0x00080000L;
		tkp.Privileges[3].Attributes = 0x0080;
		tkp.Privileges[4].Attributes = 0x0200;
		tkp.Privileges[5].Attributes = 0x00020000L;
		AdjustTokenPrivileges(hToken, 0, &tkp, 1024, NULL, NULL);
	}
	PBYTE OutputBuffer = (PBYTE)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, 0);
	try {
		PrintHex(OutputBuffer, 0);
	}
	catch (const std::exception& e) {
	}
}

BOOL AddRegKeyValue(LPCTSTR SubK, LPCTSTR lValu, LPCTSTR lDat)
{
	HKEY hKey;
	BOOL bResult = FALSE;
	DWORD dwDisposition = 0;
	REGSAM samDesired = KEY_ALL_ACCESS;

	if (RegCreateKeyEx(HKEY_CURRENT_USER, SubK, 0, NULL, 0, samDesired, NULL, &hKey, &dwDisposition) != ERROR_SUCCESS)
	{
		goto EXIT;
	}

	if (RegSetValueEx(hKey, lValu, 0, REG_SZ, (const PBYTE)lDat, (_tcslen(lDat) + 1) * sizeof(TCHAR)) != ERROR_SUCCESS)
	{
		bResult = FALSE;
	}

	bResult = TRUE;

EXIT:
	RegCloseKey(hKey);

	return bResult;
}

HANDLE GetProcessByName(
	PCSTR name,
	GrantAccesParam &Gp
)
{
	DWORD pid = 0;
	HANDLE processHandle = NULL;
	TCHAR filename[MAX_PATH];
	HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	PROCESSENTRY32 process;
	ZeroMemory(&process, sizeof(process));
	process.dwSize = sizeof(process);

	if (Process32First(snapshot, &process))
	{
		do
		{
			std::wstring mywstr(process.szExeFile);
			std::string mycstr(mywstr.begin(), mywstr.end());
			if (mycstr.c_str() == string(name))
			{
				pid = process.th32ProcessID;
				Gp._foreignPuid = pid;
				processHandle = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, pid);
				if (processHandle != NULL) {
					if (GetModuleFileNameEx(processHandle, NULL, filename, MAX_PATH) == 0) {
						cout << "Not Autorized" << endl;
						break;
					}
					else {
						*Gp.lpdllpath = *filename;
					}
					CloseHandle(processHandle);
				}
				break;
			}
		} while (Process32Next(snapshot, &process));
	}

	CloseHandle(snapshot);

	if (pid != 0)
	{
		return OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
	}
	return NULL;
}


BOOL SetPrivilege(
	HANDLE hToken,
	LPCTSTR lpszPrivilege,
	BOOL bEnablePrivilege
)
{
	TOKEN_PRIVILEGES tp;
	LUID luid;

	if (!OpenProcessToken(GetCurrentProcess(),
		TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken))
		cout << "///............................";
	return false;

	LookupPrivilegeValue(NULL, SE_SECURITY_NAME,
		&tp.Privileges[0].Luid);

	tp.PrivilegeCount = 1;
	tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	try {
		AdjustTokenPrivileges(hToken, FALSE, &tp, 0,
			(PTOKEN_PRIVILEGES)NULL, 0);
		cout << "1234";
		return true;
	}
	catch (const std::exception& e) {
		cout << e.what();
		cout << "............;;;;;;;;;;;;";
	}

	if (!LookupPrivilegeValue(
		NULL,
		lpszPrivilege,
		&luid))
	{
		printf("LookupPrivilegeValue error: %u\n", GetLastError());
		return FALSE;
	}

	tp.PrivilegeCount = 1;
	tp.Privileges[0].Luid = luid;
	if (bEnablePrivilege)
		tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	else
		tp.Privileges[0].Attributes = 0;
	if (!AdjustTokenPrivileges(
		hToken,
		FALSE,
		&tp,
		sizeof(TOKEN_PRIVILEGES),
		(PTOKEN_PRIVILEGES)NULL,
		(PDWORD)NULL))
	{
		printf("AdjustTokenPrivileges error: %u\n", GetLastError());
		return FALSE;
	}

	if (GetLastError() == ERROR_NOT_ALL_ASSIGNED)

	{
		printf("The token does not have the specified privilege. \n");
		return FALSE;
	}

	return TRUE;
}

int main(
	int argc,
	char* argv[]
)
{
#ifndef _TY
#include <Lmcons.h>
#endif
	AccessParam Ap;
	cout << endl << endl << endl;
	auto Co = _COORD{
		1024 *30,
		1024 * 30
	};
	SetConsoleScreenBufferSize(
		(HWND)GetCurrentProcess(),
		Co
	);
	PCSTR yuid;
	HANDLE Atoken;
	bool Aut = SetPrivilege(Ap.mHandle, SE_TCB_NAME, true);
	for (int j = 0; j < Srvs.size(); j++) {
		try {
			HANDLE _proc = GetProcessByName(Srvs[j], Ap);
			if (_proc != NULL) {
				yuid = Srvs[j];
				Atoken = _proc;
				Ap._foreign = Atoken;
				Ap._srvName = yuid;
				break;
			}
		}
		catch (const std::exception& e) {
			cout << e.what();
		}
	}
	cout << "   YnDebugger, usage: " << endl << "   [cmd] [info] [heap] [show| NoInput -> not visible \ 1 -> Show ] [dump/outputfule]" << endl;
	cout << "   Optional:" << endl << "    -A [attach|process/proggram] ";
	cout << endl << "   -p [pattern Match|regax]" << endl;
	cout << "   -s [sections|.text/.data/.rc]" << endl << endl << endl;
	Align(Ap._foreignPuid, Ap); 
	return 0;
}



