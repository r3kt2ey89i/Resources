#!/usr/bin/env python

# make an Hex dump Out of a diasm..

NOT = ['or','jo','jb','je','fs','js','gs','cs', 'ja']

w = 1
with open("..//",mode='w') as dl:
	with open(".///",mode="r") as rd:
		for y in rd.readlines():
			u = y.split(" ")
			for U in u:
				if len(U) == 2:
					if U not in NOT:
						w += 1
						if not w%10==0:
							dl.write('0x'+U.upper()+',')
						else:
							dl.write('0x'+U.upper()+',\n')
		dl.write(str(w-1))
