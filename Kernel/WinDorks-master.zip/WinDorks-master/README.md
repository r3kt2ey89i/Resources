# WinDorks; This repo contains loads of the windows operating system internals that i collected from many sources. In addition it contains a wdm.h override For overiding windows drivers, The solution is maid with vs 2017, (Mbed), and it compiles, so you can override wdm safe functions to have fun with the OS.
  enjoy.
  
# additional Resources:
<html><a href="https://github.com/kukuriku/WRK-1.2">WRK-1.2</a></html>
